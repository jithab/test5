---
layout: post
title:  Conversation in a Book Shop; Buying a Dictionary
date: 2010-07-10 12:03:00 +0000
categories: englishified conversation
---
<table class="see_table">
<tbody>
<tr><td class="see_who">Vijith</td><td class="see_separator">:-</td>
<td class="see_dialogue">I would like to buy a good English dictionary.<br />
Could you suggest one?</td>
</tr>
<tr><td class="see_who">Manager</td><td class="see_separator">:-</td>
<td class="see_dialogue">The best in my opinion is Oxford advanced learners dictionary. </td>
</tr>
<tr><td class="see_who">Vijith</td><td class="see_separator">:-</td>
<td class="see_dialogue">Well, heard some discount is allowed during this season.<br />
Could I get it for this dictionary too? </td>
</tr>
<tr><td class="see_who">Manager</td><td class="see_separator">:-</td>
<td class="see_dialogue">Of course, you will get 15% discount. </td>
</tr>
<tr><td class="see_who">Vijith</td><td class="see_separator">:-</td>
<td class="see_dialogue">What is the actual cost of the dictionary? </td>
</tr>
<tr><td class="see_who">Manager</td><td class="see_separator">:-</td>
<td class="see_dialogue">One hundred and fifty  only.</td>
</tr>
<tr><td class="see_who">Vijith</td><td class="see_separator">:-</td>
<td class="see_dialogue">OK, I want one. Where should I pay the cash? </td>
</tr>
<tr><td class="see_who">Manager</td><td class="see_separator">:-</td>
<td class="see_dialogue">There, at that counter.</td>
</tr>
</tbody></table>