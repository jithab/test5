---
layout: post
title:  Conversation about a Project; Expansion of Proverbs
date:   2010-07-10 12:13:00 +0000
categories: englishified conversation
---
<table class="see_table">
<tbody>
<tr>
  <td class="see_who">Mary</td>
  <td class="see_separator">:-</td>
<td class="see_dialogue">Vipi, have you been waiting long? </td>
</tr>
<tr>
  <td class="see_who">Vipin</td>
  <td class="see_separator">:-</td>
<td class="see_dialogue">No, just arrived. Why did you call me? </td>
</tr>
<tr><td class="see_who">Mary</td>
<td class="see_separator">:-</td>
<td class="see_dialogue"><span class="see_dialogue1">Haven't I told you about a project of mine? </span></td>
</tr>
<tr>
  <td class="see_who">Vipin</td>
  <td class="see_separator">:-</td>
<td class="see_dialogue">Yes, what can I do for you? </td>
</tr>
<tr><td class="see_who">Mary</td>
<td class="see_separator">:-</td>
<td class="see_dialogue">You know, my project is the expansion of proverbs.<br />
I have to choose a proverb and write a paragraph by expanding it. </td>
</tr>
<tr><td class="see_who">Vipin</td>
<td class="see_separator">:-</td>
<td class="see_dialogue">Well, let me help you. We'll first choose one and then discuss it.<br />
You write down the points- not in full sentences.<br />
But just words and phrases.<br />
Later you rearrange them in right order. OK. </td>
</tr>
<tr><td class="see_who">Mary</td>
<td class="see_separator">:-</td>
<td class="see_dialogue">OK, I've been troubling you a lot, haven't I?</td>
</tr>
<tr><td class="see_who">Vipin</td>
<td class="see_separator">:-</td>
<td class="see_dialogue">It doesn't matter. </td>
</tr>
</tbody></table>