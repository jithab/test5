---
layout: post
title: Conversation with a Bank Manager; Getting a Housing Loan
date:  2010-07-10 15:38:00 +0000
categories: englishified conversation
---
<table class="see_table">
<tbody>
<tr><td class="see_who">Manuraj</td><td class="see_separator">:-</td>
<td class="see_dialogue">I would like to have a loan for constructing a house.<br />
What is the procedure for it
?</td>
</tr>
<tr><td class="see_who">Manager</td><td class="see_separator">:-</td>
<td class="see_dialogue">Well, you can have it if you are employed and having a regular income. </td>
</tr>
<tr><td class="see_who">Manuraj</td><td class="see_separator">:-</td>
<td class="see_dialogue">Well, are there any application forms I have to fill? </td>
</tr>
<tr><td class="see_who">Manager</td><td class="see_separator">:-</td>
<td class="see_dialogue">Yes, you have to fill in this application form and get it attested by your employer and two responsible citizens. </td>
</tr>
<tr><td class="see_who">Manuraj</td><td class="see_separator">:-</td>
<td class="see_dialogue">What are your terms and conditions? </td>
</tr>
<tr><td class="see_who">Manager</td><td class="see_separator">:-</td>
<td class="see_dialogue">Oh, it is very simple. We take 14% interest on the loan.</td>
</tr>
<tr><td class="see_who">Manuraj</td><td class="see_separator">:-</td>
<td class="see_dialogue">What about installment? </td>
</tr>
<tr><td class="see_who">Manager</td><td class="see_separator">:-</td>
<td class="see_dialogue">The installment amount must be paid on the first working day of each month.</td>
</tr>
</tbody></table>