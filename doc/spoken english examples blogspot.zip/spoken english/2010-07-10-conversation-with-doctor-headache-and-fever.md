---
layout: post
title:  Conversation with a Doctor; Headache and Fever
date:   2010-07-10 11:57:00 +0000
categories: englishified conversation
---
<table class="see_table">
<tbody>
<tr><td class="see_who">Doctor</td><td class="see_separator">:-</td>
<td class="see_dialogue">Come in Sidharth. Be seated. </td>
</tr>
<tr><td class="see_who">Sidharth</td><td class="see_separator">:-</td>
<td class="see_dialogue">Doctor, no appetite for the last two days.<br />
Can't even sleep well.</td>
</tr>
<tr><td class="see_who">Doctor</td><td class="see_separator">:-</td>
<td class="see_dialogue">Let me examine. Any fever? </td>
</tr>
<tr><td class="see_who">Sidharth</td><td class="see_separator">:-</td>
<td class="see_dialogue">No fever. Had a slight headache yesterday. </td>
</tr>
<tr><td class="see_who">Doctor</td><td class="see_separator">:-</td>
<td class="see_dialogue">I see. Now you have a slight temperature. </td>
</tr>
<tr><td class="see_who">Sidharth</td><td class="see_separator">:-</td>
<td class="see_dialogue">Can I attend the class? </td>
</tr>
<tr><td class="see_who">Doctor</td><td class="see_separator">:-</td>
<td class="see_dialogue">No. You are very week.<br />
Better rest for a few days.</td>
</tr>
<tr><td class="see_who">Sidharth</td><td class="see_separator">:-</td>
<td class="see_dialogue">OK, doctor. </td>
</tr>
<tr>
  <td class="see_who">Doctor</td><td class="see_separator">:-</td>
<td class="see_dialogue">Have these tables. Complete this course.<br />
Take rest also. Don't worry.</td>
</tr>
</tbody></table>