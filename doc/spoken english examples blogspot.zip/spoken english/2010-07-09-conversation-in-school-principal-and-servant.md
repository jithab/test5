---
layout: post
title:  Conversation in a School Office; Principal and Servant
date:   2010-07-09 14:33:00 +0000
categories: englishified conversation
---
<table class="see_table"><tbody>
<tr><td class="see_who">Servant</td><td class="see_separator">:-</td><td class="see_dialogue">Sir, a man wants to see you.</td></tr>
<tr><td class="see_who">Principal</td><td class="see_separator">:-</td><td class="see_dialogue">I receive parents only during office hours.<br />
The particular office hours are posted on the notice-board.<br />
Tell him that.</td></tr>
<tr><td class="see_who">Servant</td><td class="see_separator">:-</td><td class="see_dialogue">Yes, sir. But it isn't parent sir.</td></tr>
<tr><td class="see_who">Principal</td><td class="see_separator">:-</td><td class="see_dialogue">A pupil?</td></tr>
<tr><td class="see_who">Servant</td><td class="see_separator">:-</td><td class="see_dialogue">I don't think so. He has a beard.</td></tr>
<tr><td class="see_who">Principal</td><td class="see_separator">:-</td><td class="see_dialogue">Not a parent and not a pupil? Then what is he?<br />
What is he look like? Stupid? Intelligent?</td></tr>
<tr><td class="see_who">Servant</td><td class="see_separator">:-</td><td class="see_dialogue">Fairly Intelligent, I'd say sir.</td></tr>
<tr><td class="see_who">Principal</td><td class="see_separator">:-</td><td class="see_dialogue">Good! Then he is not a School Inspector. Show him in.</td></tr>
<tr><td class="see_who">Servant</td><td class="see_separator">:-</td><td class="see_dialogue">Yes sir.</td></tr>
</tbody></table>