---
layout: post
title: Conversation with a Stranger; Introducing Yourself
date: 2010-07-10 12:34:00 +0000
categories: englishified conversation
---
<table class="see_table">
<tbody>
<tr><td class="see_who">Sony</td><td class="see_separator">:-</td>
<td class="see_dialogue">Excuse me, my name is Sony.<br />
I don't think we have met before, have we?</td>
</tr>
<tr><td class="see_who">John</td><td class="see_separator">:-</td>
<td class="see_dialogue">I'm John. You're quite right.<br />
I don't think we have met before. Very happy to meet you. </td>
</tr>
<tr><td class="see_who">Sony</td><td class="see_separator">:-</td>
<td class="see_dialogue"><span class="see_dialogue1">Thank you.<br />Would you please let me know something about you? </span></td>
</tr>
<tr><td class="see_who">John</td><td class="see_separator">:-</td>
<td class="see_dialogue">Thanks. I'm a new-comer here.<br />
But my grandparents are quite used to this place.<br />
I've been with my parents at Kashmir. </td>
</tr>
<tr><td class="see_who">Sony</td><td class="see_separator">:-</td>
<td class="see_dialogue">Kashmir! When did you come here? </td>
</tr>
<tr><td class="see_who">John</td><td class="see_separator">:-</td>
<td class="see_dialogue">Only last week. Now we have vocation.<br />
I want to spend my vocation with my grandparents. </td>
</tr>
<tr><td class="see_who">Sony</td><td class="see_separator">:-</td>
<td class="see_dialogue">It's of course very nice.<br />
I hope you can tell me more about Kashmir.</td>
</tr>
<tr><td class="see_who">John</td><td class="see_separator">:-</td>
<td class="see_dialogue">Certainly. And you can tell me much about this beautiful village. </td>
</tr>
<tr>
  <td class="see_who">Sony</td><td class="see_separator">:-</td>
<td class="see_dialogue">With pleasure. Sorry mother is calling me.<br />
Let's meet here at 10. I'll be free then. </td>
</tr>
</tbody></table>