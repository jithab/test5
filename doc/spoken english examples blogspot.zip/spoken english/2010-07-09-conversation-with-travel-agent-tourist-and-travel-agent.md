---
layout: post
title:  Conversation with Travel Agent; Tourist and Travel Agent
date:   2010-07-09 16:09:00 +0000
categories: englishified conversation
---
<table class="see_table">
<tbody>
<tr><td class="see_who">Tourist</td><td class="see_separator">:-</td>
<td class="see_dialogue">I would like to go to Kolkatta.<br />
Is there any conveyance to Kolkatta?</td>
</tr>
<tr><td class="see_who">Agent</td><td class="see_separator">:-</td>
<td class="see_dialogue">Of course, a tourist bus leaves here for <span class="see_dialogue1">Kolkatta</span> daily. </td>
</tr>
<tr><td class="see_who">Tourist</td><td class="see_separator">:-</td>
<td class="see_dialogue">How long will it take to reach<span class="see_dialogue1"> Kolkatta?</span></td>
</tr>
<tr><td class="see_who">Agent</td><td class="see_separator">:-</td>
<td class="see_dialogue">Two days. </td>
</tr>
<tr><td class="see_who">Tourist</td><td class="see_separator">:-</td>
<td class="see_dialogue">How much is the fare? </td>
</tr>
<tr><td class="see_who">Agent</td><td class="see_separator">:-</td>
<td class="see_dialogue">Rs 900 only.</td>
</tr>
<tr><td class="see_who">Tourist</td><td class="see_separator">:-</td>
<td class="see_dialogue">When does it start from here? </td>
</tr>
<tr><td class="see_who">Agent</td><td class="see_separator">:-</td>
<td class="see_dialogue">Early morning, at 6 O'clock.</td>
</tr>
<tr><td class="see_who">Tourist</td><td class="see_separator">:-</td>
<td class="see_dialogue">All right. Could you book one seat for me? </td>
</tr>
<tr><td class="see_who">Agent</td>
<td class="see_separator">:-</td>
<td class="see_dialogue">Surely sir, give me your address.  </td>
</tr>
<tr><td class="see_who">Tourist</td><td class="see_separator">:-</td>
<td class="see_dialogue">Thank you, you are very helpful. </td>
</tr>
<tr><td class="see_who">Agent</td>
<td class="see_separator">:-</td>
<td class="see_dialogue">Don't mention it. It is my duty only. </td>
</tr>
</tbody></table>